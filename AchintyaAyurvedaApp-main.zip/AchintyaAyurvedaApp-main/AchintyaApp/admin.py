from django.contrib import admin
from .models import Doctors, ClinicStaff, PatientInfo, Appointments, Prescriptions, NextVisits, Medicines

# Register your models here.

admin.site.register(Doctors)
admin.site.register(ClinicStaff)
admin.site.register(PatientInfo)
admin.site.register(Appointments)
admin.site.register(Prescriptions)
admin.site.register(NextVisits)
admin.site.register(Medicines)
