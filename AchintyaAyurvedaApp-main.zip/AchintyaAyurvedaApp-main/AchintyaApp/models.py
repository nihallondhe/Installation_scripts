from django.db import models
from django.contrib.auth.models import User

# Create your models here.

class Doctors(models.Model):
    name = models.CharField(max_length=50)
    registration_id = models.CharField(max_length=50)
    mobile_number = models.CharField(max_length=13)
    education = models.CharField(max_length=50)
    city = models.CharField(max_length=50)
    date_of_birth = models.CharField(max_length=50)
    specialization = models.CharField(max_length=50)

    def __str__(self):
        return self.name


class ClinicStaff(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name="staff")
    name = models.CharField(max_length=512)
    role = models.CharField(max_length=512)
    email = models.EmailField()
    phone = models.CharField(max_length=12)

    def __str__(self):
        return f'{self.name} {self.email}'


class PatientInfo(models.Model):
    patient_name = models.CharField(max_length=100)
    patient_occupation = models.CharField(max_length=100)
    patient_age = models.CharField(max_length=3)
    patient_weight = models.CharField(max_length=5)
    patient_blood_group = models.CharField(max_length=10)
    patient_BP = models.CharField(max_length=50)
    patient_gender = models.CharField(max_length=10)
    patient_mobile_number = models.CharField(max_length=13)
    patient_email = models.EmailField()
    patient_visit_date = models.DateField(auto_now=False, auto_now_add=False)
    patient_birth_date = models.DateField(auto_now=False, auto_now_add=False)
    patient_address = models.CharField(max_length=500)
    patient_city = models.CharField(max_length=50)
    pin_code = models.CharField(max_length=50)
    patient_state = models.CharField(max_length=50)
    doctor_reference = models.CharField(max_length=100)
    hospital_location = models.CharField(max_length=100)
    checking_fees = models.BigIntegerField()

    def __str__(self):
        return self.patient_name


class Appointments(models.Model):
    patient_fk = models.ForeignKey(PatientInfo, on_delete=models.CASCADE)
    patient_name = models.CharField(max_length=100)
    mobile_number = models.CharField(max_length=13)
    patient_age = models.CharField(max_length=3, default=50)
    patient_weight = models.CharField(max_length=5, default=60)
    date = models.DateTimeField(auto_now=False, auto_now_add=False)
    doctor_name = models.CharField(max_length=50)
    hospital_location = models.CharField(max_length=50)
    patient_city = models.CharField(max_length=50)
    checking_fees = models.CharField(max_length=5, default=300)

    def __str__(self):
        return self.name


class PatientSymptoms(models.Model):
    pass

    
class Prescriptions(models.Model):
    patient_fk = models.ForeignKey(Appointments, on_delete=models.CASCADE, default = 1)
    medicine_name = models.CharField(max_length=50)
    medicine_type = models.CharField(max_length=50)
    morning_dose = models.CharField(max_length=20)
    afternoon_dose = models.CharField(max_length=20)
    night_dose = models.CharField(max_length=20)
    dose_timing = models.CharField(max_length=50)
    dose_with = models.CharField(max_length=100)
    course_duration = models.CharField(max_length=50)
    
    def __str__(self):
        return self.medicine_name


class NextVisits(models.Model):
    patient_fk = models.ForeignKey(Appointments, on_delete=models.CASCADE, default = 1)
    next_visit_date = models.DateField(auto_now=False, auto_now_add=False)
    note = models.CharField(max_length = 500)
    panchkarma = models.CharField(max_length=500)

    def __str__(self):
        return self.next_visit_date


class Medicines(models.Model):
    medicine_name = models.CharField(max_length=100)
    medicine_type = models.CharField(max_length=50)

    def __str__(self):
        return self.medicine_name
        

class Income(models.Model):
    date = models.DateField(auto_now=False, auto_now_add=True)
    patient_name = models.CharField(max_length=50)
    Amount = models.CharField(max_length=50)
    doctor_name = models.CharField(max_length=50)


class PatientHistory(models.Model):
    pass


class PaymentHistory(models.Model):
    pass

