from django.contrib import admin
from django.urls import path, include
from AchintyaApp import views

urlpatterns = [
    path('', views.index, name='index'),
    path('loginUser', views.loginUser, name='loginUser'),
    path('logoutUser', views.logoutUser, name='logoutUser'),
    path('registerUser', views.registerUser, name='registerUser'),

    path('dashboard', views.dashboard, name='dashboard'),
    path('patientAppointment', views.patientAppointment, name='patientAppointment'),
    path('appointments', views.appointments, name='appointments'),
    path('makeappointment/<int:id>', views.makeappointment, name='makeappointment'),
    path('registrationrecords/<int:id>', views.registrationrecords, name='registrationrecords'),
    path('editappointment/<int:id>', views.editappointment, name='editappointment'),
    path('deleteappointment/<int:id>', views.deleteappointment, name='deleteappointment'),
       
    path('medicines', views.medicines, name='medicines'),
    path('addmedicine', views.addmedicine, name='addmedicine'),
    path('deletemedicine/<int:id>', views.deletemedicine, name='deletemedicine'),
    path('editmedicine/<int:id>', views.editmedicine, name='editmedicine'),

    path('deletepatient/<int:id>', views.deletepatient, name='deletepatient'),
    path('editpatient/<int:id>', views.editpatient, name='editpatient'),
    path('viewpatient/<int:id>', views.viewpatient, name='viewpatient'),

    path('paymentreceipt/<int:id>', views.paymentreceipt, name='paymentreceipt'),
    path('staff', views.staff, name='staff'),
    path('deletestaff/<int:id>', views.deletestaff, name='deletestaff'),

    path('patientsymptoms/<int:id>', views.patientsymptoms, name='patientsymptoms'),

    path('prescription/<int:id>', views.prescription, name='prescription'),
    path('patientnextvisit/<int:id>', views.patientnextvisit, name='patientnextvisit'),

    path('prescriptionlist', views.prescriptionlist, name='prescriptionlist'),
    path('prescriptionrecords/<int:id>', views.prescriptionrecords, name='prescriptionrecords'),
    path('prescriptionprint/<int:id>', views.prescriptionprint, name='prescriptionprint'),
    

]
