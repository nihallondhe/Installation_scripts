from django.apps import AppConfig


class AchintyaappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'AchintyaApp'
