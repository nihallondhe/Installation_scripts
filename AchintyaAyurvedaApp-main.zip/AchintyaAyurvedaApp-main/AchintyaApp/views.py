from django.shortcuts import render
from django.contrib.auth import login
from django.contrib.auth import logout
from django.shortcuts import redirect
from django.contrib.auth import authenticate
from django.shortcuts import HttpResponse
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.views.decorators.http import require_http_methods
from django.http import JsonResponse
from .models import ClinicStaff, Doctors, PatientInfo
from .models import Appointments
from .models import Medicines, NextVisits, Prescriptions
from .forms import PatientRegistrationList, PatientRecordList, PrescriptionRecordList
from .forms import PrescriptionSearchList, MedicineList, StaffList

# Create your views here.

def index(request):
    if request.user.is_anonymous:
        return redirect('/loginUser')
    else:
        return redirect('/dashboard')

def medicines(request):
    medicines = Medicines.objects.all()
    context = {
        'medicines' : medicines,
        
    }
    return render(request, 'html/medicine.html', context)

def loginUser(request):
    if request.method == "POST":
        usern = request.POST.get('username')
        userp = request.POST.get('password')
        user = authenticate(request, username=usern, password=userp)
        if user:
            login(request, user)
            return redirect('/')
    else:
        return render(request,'html/user-signin.html')
    return render(request,'html/user-signin.html')

def logoutUser(request):
    logout(request)
    return redirect('/loginUser')

def registerUser(request):
    if request.method == 'POST':
        form = request.POST
        name = form.get('username','')
        password = form.get('password', '')
        confirm_password = form.get('confirmPassword', '')
        phone = form.get('phone', '')
        email = form.get('email','')
        role = form.get("role", '')

        if password == confirm_password and password != '':
            u = User.objects.create(username = email, email = email, first_name = name, last_name = role)
            u.set_password(password)
            u.save()

            s = ClinicStaff()
            s.user = u
            s.email = u.email
            s.name = name
            s.role = role
            s.phone = phone
            s.save()
            
            return redirect('/loginUser')
    return render(request, 'html/user-signup.html')

def dashboard(request):
    staff = ClinicStaff.objects.all()
    doctors = Doctors.objects.all()
    patients = PatientInfo.objects.all()
    medicines = Medicines.objects.all()
    appointments = Appointments.objects.all()
    prescriptions = Prescriptions.objects.all()
    context = {
        'staff' : len(staff),
        'patients' : len(patients),
        'numbers' : len(medicines),
        'doctors' : len(doctors),
        'appointments' : len(appointments),
        'prescriptions' : len(prescriptions),
    }
    return render(request, 'html/dashboard.html', context)

def patientAppointment(request):
    if request.method == 'POST':
        if 'Register' in request.POST:
            form = request.POST
            patient_name = form.get('patient_name', '')
            patient_occupation = form.get('patient_occupation', '') 
            patient_age = form.get('patient_age', '')
            patient_weight = form.get('patient_weight', '')
            patient_BP = form.get('patient_BP', '')
            patient_blood_group = form.get('p_blood_group', '')
            patient_gender = form.get('patient_gender', '') 
            patient_mobile_number = form.get('patient_mobile_no', '')
            patient_email =  form.get('patient_email', '')
            patient_visit_date = form.get('visit_date', '')
            patient_birth_date = form.get('birthday_date', '')
            patient_address = form.get('patient_address', '')
            patient_state = form.get('patient_state', '')
            patient_city = form.get('patient_city', '')
            patient_pin_code = form.get('patient_pin_code', '')
            doctor_reference = form.get('doctor_reference', '')
            hospital_location = form.get('hospital_location', '')
            checking_fees = form.get('checking_fees', '')

            patients = PatientInfo.objects.create(patient_name = patient_name, patient_occupation = patient_occupation, \
                patient_age = patient_age, patient_weight = patient_weight, patient_BP = patient_BP, patient_blood_group = patient_blood_group, \
                patient_gender = patient_gender, patient_mobile_number = patient_mobile_number, patient_email = patient_email, \
                patient_visit_date = patient_visit_date, patient_birth_date = patient_birth_date, patient_address = patient_address, patient_state = patient_state, \
                patient_city = patient_city, pin_code = patient_pin_code, doctor_reference = doctor_reference, hospital_location = hospital_location, checking_fees = checking_fees)
            return redirect('/appointments')
    return render(request, 'html/patient-registration.html')

def appointments(request):
    form = PatientRegistrationList(request.GET)
    patients = PatientInfo.objects.all()
    if form.is_valid() and 'search_query' in form.cleaned_data:
        search_query = form.cleaned_data['search_query']
        patients = patients.filter(patient_name__icontains = search_query)
    return render(request, 'html/registrations.html', {'patients' : patients, 'form' : form})

def deletepatient(request, id):
    patient = PatientInfo.objects.get(id = id)
    records = Appointments.objects.get(patient_fk = id)
    if not patient:
        return redirect('/patientAppointment')
    if patient:
        patient.delete()
        records.delete()
    return redirect('/appointments')

def editpatient(request, id):
    patient = PatientInfo.objects.get(id = id)
    if not patient:
        return redirect('/patientAppointment')
    if request.method == 'POST':
        if 'Back' in request.POST:
            return redirect('/appointments')
        if 'Update' in request.POST:
            form = request.POST
            patient_name = form.get('patient_name', '')
            patient_occupation = form.get('patient_occupation', '') 
            patient_age = form.get('patient_age', '')
            patient_weight = form.get('patient_weight', '')
            patient_blood_group = form.get('p_blood_group', '')
            patient_gender = form.get('patient_gender', '') 
            patient_mobile_number = form.get('patient_mobile_no', '')
            patient_email =  form.get('patient_email', '')
            patient_visit_date = form.get('visit_date', '')
            patient_birth_date = form.get('birthday_date', '')
            patient_address = form.get('patient_address', '')
            doctor_reference = form.get('doctor_reference', '')
            hospital_location = form.get('hospital_location', '')
            checking_fees = form.get('checking_fees', '')

            if '' not in ['patient_name', 'patient_occupation', 'patient_age', 'patient_weight', 'patient_blood_group', 'patient_gender',\
                'patient_mobile_number', 'patient_email','patient_birth_date', "patient_visit_date", 'patient_address', 'doctor_reference',\
                'hospital_location', 'checking_fees']:
                patient.patient_name = patient_name
                patient.patient_occupation = patient_occupation 
                patient.patient_age = patient_age
                patient.patient_weight = patient_weight
                patient.patient_blood_group = patient_blood_group
                patient.patient_gender = patient_gender 
                patient.patient_mobile_number = patient_mobile_number
                patient.patient_email =  patient_email 
                patient.patient_visit_date = patient_visit_date
                patient.patient_birth_date = patient_birth_date
                patient.patient_address = patient_address
                patient.doctor_reference = doctor_reference
                patient.hospital_location = hospital_location
                patient.checking_fees = checking_fees
                patient.save()
                return redirect('/appointments')
    UpdatedPatients = {
        'patients' : patient
    }
    return render(request, 'html/edit-patient.html', UpdatedPatients)

def makeappointment(request, id):
    record = PatientInfo.objects.get(id = id)
    doctors = Doctors.objects.all()
    context = {
        'doctors' : doctors,
        'record' : record,
    }
    if request.method == 'POST' and 'Register' in request.POST:
        form = request.POST
        patient_fk = record
        patient_name = form.get('patient_name', '')
        patient_mobile_number = form.get('patient_mobile_no', '')
        patient_age = form.get('patient_age', '')
        patient_weight = form.get('patient_weight', '')
        patient_visit_date = form.get('visit_date', '')
        doctor_reference = form.get('doctor_reference', '')
        patient_city = form.get('patient_city', '')
        hospital_location = form.get('hospital_location', '')
        checking_fees = form.get('checking_fees', '')
        appointments = Appointments.objects.create(patient_fk = patient_fk, patient_name = patient_name, mobile_number = patient_mobile_number, \
            patient_age = patient_age, patient_weight = patient_weight, date = patient_visit_date, doctor_name = doctor_reference, \
            hospital_location = hospital_location, patient_city = patient_city, checking_fees = checking_fees)
        return redirect('/appointments')
    return render(request, 'html/make-appointment.html', context)
    
def registrationrecords(request, id):
    form = PatientRecordList(request.GET)
    patient = PatientInfo.objects.get(id = id)
    records = Appointments.objects.filter(patient_fk = id).all()
    if form.is_valid() and 'search_query' in form.cleaned_data:
        search_query = form.cleaned_data['search_query']
        records = records.filter(date__icontains = search_query)
    return render(request, 'html/registration-record.html', {'records' : records, 'form' : form, 'patient' : patient})

def editappointment(request, id):
    record = Appointments.objects.get(id = id)
    doctors = Doctors.objects.all()
    context = {
        'doctors' : doctors,
        'record' : record,
    }
    if request.method == 'POST' and 'Edit' in request.POST:
        form = request.POST
        patient_fk = record
        patient_name = form.get('patient_name', '')
        patient_mobile_number = form.get('patient_mobile_no', '')
        patient_age = form.get('patient_age', '')
        patient_weight = form.get('patient_weight', '')
        patient_visit_date = form.get('visit_date', '')
        doctor_reference = form.get('doctor_reference', '')
        patient_city = form.get('patient_city', '')
        hospital_location = form.get('hospital_location', '')
        checking_fees = form.get('checking_fees', '')

        record.patient_name = patient_name
        record.mobile_number = patient_mobile_number
        record.patient_age = patient_age
        record.patient_weight = patient_weight
        record.date = patient_visit_date
        record.doctor_name = doctor_reference
        record.patient_city = patient_city
        record.hospital_location = hospital_location
        record.checking_fees = checking_fees
        record.save()
        return redirect('/appointments')
    return render(request, 'html/edit-appointment.html', context)

def deleteappointment(request, id):
    record = Appointments.objects.get(id = id)
    if not record:
        return redirect('/makeappointment')
    if record:
        record.delete()
    return render(request, 'html/registration-record.html')

def medicines(request):
    form = MedicineList(request.GET)
    medicines = Medicines.objects.all()
    if form.is_valid() and 'search_query' in form.cleaned_data:
        search_query = form.cleaned_data['search_query']
        medicines = medicines.filter(medicine_name__icontains = search_query)
    # if form.is_valid() and 'search_query' in form.cleaned_data:
    #     search_query = form.cleaned_data['search_query']
    #     medicines = medicines.filter(medicine_type__icontains = search_query)
    return render(request, 'html/medicine-list.html', {'medicines' : medicines, 'form' : form})

def addmedicine(request):
    if request.method == 'POST' and 'Add' in request.POST:
        form = request.POST
        medicine_name = form.get('name', '')
        medicine_type = form.get('med_type', '')

        medicine = Medicines.objects.create(medicine_name = medicine_name, medicine_type = medicine_type)
        return redirect('/medicines')
    return render(request, 'html/add-medicine.html')

def deletemedicine(request, id):
    medicine = Medicines.objects.get(id = id)
    if not medicine:
        return redirect('/addmedicine')
    if medicine:
        medicine.delete()

def editmedicine(request, id):
    medicine = Medicines.objects.get(id = id)
    if request.method == 'POST' and 'Edit' in request.POST:
        form = request.POST
        medicine_name = form.get('name', '')
        medicine_type = form.get('med_type', '')

        medicine.medicine_name = medicine_name
        medicine.medicine_type = medicine_type
        medicine.save()
        return redirect('/medicines')
    return render(request, 'html/edit-medicine.html', {'medicine' : medicine})

def paymentreceipt(request, id):
    patient = Appointments.objects.get(id = id)
    payments = {
        'patient' : patient
    }
    return render(request, 'html/payment-receipt.html', payments)

def viewpatient(request, id):
    patient = PatientInfo.objects.get(id = id)
    patient_info = {
        'patient' : patient
    }
    return render(request, 'html/patient-info-view.html', patient_info)

def patientsymptoms(request):
    pass


def prescription(request, id):
    medicines = Medicines.objects.all()
    p = Appointments.objects.get(id = id)
    if request.method == 'POST':
        if 'Back' in request.POST:
            return redirect('/appointments')
        if 'Add' in request.POST:
            form = request.POST
            patient_fk = p
            medicine_type = form.get('medicine_type', '')
            medicine_name = form.get('medicine_name', '')
            medicine_morning_dose = form.get('medicine_morning', '')
            medicine_noon_dose = form.get('medicine_afternoon', '')
            medicine_night_dose = form.get('medicine_night', '')
            dose_type = form.get('medicine_doses', '')
            dose_with = form.get('medicine_with', '')
            course_duration = form.get('course_duration', '')

            prescription = Prescriptions.objects.create(patient_fk = patient_fk, medicine_type = medicine_type, medicine_name = medicine_name, \
                morning_dose = medicine_morning_dose, afternoon_dose = medicine_noon_dose, night_dose = medicine_night_dose, \
                dose_timing = dose_type, dose_with = dose_with, course_duration = course_duration)
        if 'Next' in request.POST:
            form = request.POST
            patient_fk = Appointments.objects.get(id=id)
            medicine_type = form.get('medicine_type', '')
            medicine_name = form.get('medicine_name', '')
            medicine_morning_dose = form.get('medicine_morning', '')
            medicine_noon_dose = form.get('medicine_afternoon', '')
            medicine_night_dose = form.get('medicine_night', '')
            dose_type = form.get('medicine_doses', '')
            dose_with = form.get('medicine_with', '')
            course_duration = form.get('course_duration', '')

            prescription = Prescriptions.objects.create(patient_fk = patient_fk, medicine_type = medicine_type, medicine_name = medicine_name, \
                morning_dose = medicine_morning_dose, afternoon_dose = medicine_noon_dose, night_dose = medicine_night_dose, \
                dose_timing = dose_type, dose_with = dose_with, course_duration = course_duration)
            return redirect('/appointments')
    return render(request, 'html/prescription.html', {'medicines' : medicines})

def patientnextvisit(request, id):
    p = Appointments.objects.get(id = id)
    if request.method == 'POST':
        if 'Back' in request.POST:
            return redirect('/appointments')
        if 'Addnextvisit' in request.POST:
            form = request.POST
            patient_fk = p
            nextVisit = form.get('next_date', '')
            notes = form.get('notes', '')
            panchkarma = form.get('panchkarma', '')
            nv = NextVisits.objects.create(patient_fk = patient_fk, next_visit_date = nextVisit, note = notes, panchkarma = panchkarma)
            return redirect('/appointments')
    return render(request, 'html/patient-nextvisit.html')

def staff(request):
    form = StaffList(request.GET)
    staff = ClinicStaff.objects.all()
    if form.is_valid() and 'search_query' in form.cleaned_data:
        search_query = form.cleaned_data['search_query']
        staff = staff.filter(name__icontains = search_query)
    return render(request, 'html/staff-info.html', {'staff' : staff, 'form' : form})

def deletestaff(request, id):
    staff = ClinicStaff.objects.get(id = id)
    if staff:
        staff.delete()

def prescriptionlist(request):
    form = PrescriptionSearchList(request.GET)
    patients = PatientInfo.objects.all()
    if form.is_valid() and 'search_query' in form.cleaned_data:
        search_query = form.cleaned_data['search_query']
        patients = patients.filter(patient_name__icontains = search_query)
    return render(request, 'html/prescription-list.html', {'patients' : patients, 'form' : form})
        

def prescriptionrecords(request, id):
    form = PrescriptionRecordList(request.GET)
    records = Appointments.objects.filter(patient_fk = id).all()
    if form.is_valid() and 'search_query' in form.cleaned_data:
        search_query = form.cleaned_data['search_query']
        records = records.filter(date__icontains = search_query)
    return render(request, 'html/prescription-records.html', {'records' : records, 'form' : form})


def prescriptionprint(request, id):
    context = {
        'appointment' : Appointments.objects.get(id = id),
        'prescriptions' : Prescriptions.objects.filter(patient_fk = id).all(),
        'next_visit' : NextVisits.objects.get(patient_fk = id)
    }
    return render(request, 'html/prescription-print.html', context)
            

def deleteprescriptionrecord(request, id):
    patient = Prescriptions.objects.get(patient_fk = id)
    next_visit = NextVisits.objects.get(Patient_fk = id)
    if not patient or not next_visit:
        return redirect('/patientAppointment')
    if patient:
        patient.delete()
        next_visit.delete()
    return redirect('prescriptionlist')







