from django import forms
from .models import ClinicStaff


class ClinicStaffForm(forms.ModelForm):
    class Meta:
        model = ClinicStaff
        fields = '__all__'

class PatientRegistrationList(forms.Form):
    search_query = forms.CharField(label='', widget = forms.TextInput(attrs = {'placeholder' : 'Enter patient name...', 'class' : 'form-control'}), required = False)


class PatientRecordList(forms.Form):
    search_query = forms.CharField(label='', widget = forms.TextInput(attrs = {'placeholder' : 'Enter date...', 'class' : 'form-control'}), required = False)


class PrescriptionSearchList(forms.Form):
    search_query = forms.CharField(label='', widget = forms.TextInput(attrs = {'placeholder' : 'Enter patient name...', 'class' : 'form-control'}), required = False)


class PrescriptionRecordList(forms.Form):
    search_query = forms.CharField(label='', widget = forms.TextInput(attrs = {'placeholder' : 'Enter date...', 'class' : 'form-control'}), required = False)


class MedicineList(forms.Form):
    search_query = forms.CharField(label='', widget = forms.TextInput(attrs = {'placeholder' : 'Enter medicine name...', 'class' : 'form-control'}), required = False)


class StaffList(forms.Form):
    search_query = forms.CharField(label='', widget = forms.TextInput(attrs = {'placeholder' : 'Enter Staff name...', 'class' : 'form-control'}), required = False)




